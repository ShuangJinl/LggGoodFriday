package com.thelgg.thejinx.client.network;

import com.thelgg.thejinx.network.payload.ScreenStatePayload;
import com.thelgg.thejinx.network.payload.LaunchJinxPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

public final class JinxClientNetworking {
    private static Boolean lastScreenOpen = null;
    private static boolean lastAttackPressed = false;

    private JinxClientNetworking() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(JinxClientNetworking::syncScreenStateIfNeeded);

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            lastScreenOpen = null;
            lastAttackPressed = false;
        });
    }

    private static void syncScreenStateIfNeeded(class_310 client) {
        if (client.field_1724 == null || client.method_1562() == null) {
            return;
        }

        boolean screenOpen = client.field_1755 != null;
        if (lastScreenOpen == null || lastScreenOpen != screenOpen) {
            ClientPlayNetworking.send(new ScreenStatePayload(screenOpen));
            lastScreenOpen = screenOpen;
        }

        boolean attackPressed = client.field_1690.field_1886.method_1434();
        if (attackPressed && !lastAttackPressed && client.field_1755 == null) {
            ClientPlayNetworking.send(new LaunchJinxPayload());
        }
        lastAttackPressed = attackPressed;
    }
}
