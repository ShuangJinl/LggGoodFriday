package com.thelgg.thejinx.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.game.JinxDeathScoreboard;
import com.thelgg.thejinx.game.JinxFeatureFlags;
import com.thelgg.thejinx.game.JinxGameState;
import java.util.List;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12086;
import net.minecraft.class_12094;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

public final class JinxCommand {
    private static final String DEFAULT_JINX_NAME = "TheLgg_";

    private JinxCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("jinx")
                .requires(JinxCommand::isCommandAdmin)
                .then(class_2170.method_9247("start")
                        .executes(context -> executeStart(context.getSource())))
                .then(class_2170.method_9247("stop")
                        .executes(context -> executeStop(context.getSource())))
                .then(class_2170.method_9247("status")
                        .executes(context -> executeStatus(context.getSource())))
                .then(class_2170.method_9247("screenlift")
                        .executes(context -> executeScreenLiftQuery(context.getSource()))
                        .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(context -> executeScreenLiftSet(
                                        context.getSource(),
                                        BoolArgumentType.getBool(context, "enabled")
                                ))))
                .then(class_2170.method_9247("set")
                        .executes(context -> executeSetWithDefault(context.getSource()))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .executes(context -> executeSetByPlayer(context.getSource(), class_2186.method_9315(context, "player"))))));
    }

    private static boolean isCommandAdmin(class_2168 source) {
        if (source.method_75037() == net.minecraft.class_12096.field_63208) {
            return true;
        }
        if (source.method_75037() instanceof class_12086 leveled) {
            return leveled.method_75009().method_75028(class_12094.field_63198);
        }
        return false;
    }

    private static int executeStart(class_2168 source) {
        if (JinxGameState.isStarted()) {
            source.method_9226(() -> class_2561.method_43473()
                    .method_10852(JinxText.game("倒霉蛋"))
                    .method_10852(JinxText.muted(" 游戏已经处于 "))
                    .method_10852(JinxText.accent("开启"))
                    .method_10852(JinxText.muted(" 状态。")), false);
            return 1;
        }

        JinxGameState.setStarted(true);

        MinecraftServer server = source.method_9211();
        if (!JinxGameState.hasAnyJinx(server)) {
            class_3222 chosen = JinxGameState.pickDefaultOrRandom(server, DEFAULT_JINX_NAME);
            if (chosen != null) {
                JinxGameState.assignJinx(server, chosen);
                source.method_9226(() -> class_2561.method_43473()
                        .method_10852(JinxText.good("游戏已开启 "))
                        .method_10852(JinxText.muted("当前倒霉蛋："))
                        .method_10852(JinxText.player(chosen)), true);
                announceGameStarted(server);
                JinxDeathScoreboard.show(server);
                return 1;
            }
        }

        source.method_9226(() -> class_2561.method_43473().method_10852(JinxText.good("游戏已开启。")), true);
        announceGameStarted(server);
        JinxDeathScoreboard.show(server);
        return 1;
    }

    private static int executeSetWithDefault(class_2168 source) {
        class_3222 chosen = JinxGameState.pickDefaultOrRandom(source.method_9211(), DEFAULT_JINX_NAME);
        if (chosen == null) {
            source.method_9213(class_2561.method_43473().method_10852(JinxText.warn("当前没有在线玩家，无法设置倒霉蛋。")));
            return 0;
        }

        JinxGameState.assignJinx(source.method_9211(), chosen);
        source.method_9226(() -> class_2561.method_43473()
                .method_10852(JinxText.accent("已设置唯一倒霉蛋："))
                .method_10852(JinxText.player(chosen)), true);
        JinxFeedback.actionBar(
                chosen,
                class_2561.method_43473()
                        .method_10852(JinxText.game("管理员"))
                        .method_10852(JinxText.muted(" 将你设为 "))
                        .method_10852(JinxText.warn("唯一倒霉蛋"))
                        .method_10852(JinxText.muted("！"))
        );
        JinxFeedback.playSound(chosen, class_3417.field_14627, 0.6F, 0.8F);
        return 1;
    }

    private static int executeStop(class_2168 source) {
        if (!JinxGameState.isStarted()) {
            source.method_9226(() -> class_2561.method_43473()
                    .method_10852(JinxText.muted("倒霉蛋游戏当前 "))
                    .method_10852(JinxText.warn("未开启"))
                    .method_10852(JinxText.muted("。")), false);
            return 1;
        }

        MinecraftServer server = source.method_9211();
        JinxDeathScoreboard.hide(server);
        JinxGameState.setStarted(false);
        JinxGameState.clearJinx(server);
        source.method_9226(() -> class_2561.method_43473()
                .method_10852(JinxText.good("倒霉蛋游戏已停止"))
                .method_10852(JinxText.muted("，已清除所有倒霉蛋身份。")), true);
        JinxFeedback.broadcastTitle(
                server,
                JinxText.game("倒霉蛋游戏"),
                class_2561.method_43473().method_10852(JinxText.muted("游戏 ")).method_10852(JinxText.accent("已结束")),
                10,
                60,
                20
        );
        for (class_3222 p : server.method_3760().method_14571()) {
            JinxFeedback.playSound(p, class_3417.field_15195, 0.35F, 1.2F);
        }
        return 1;
    }

    private static void announceGameStarted(MinecraftServer server) {
        List<class_3222> jinxes = JinxGameState.getJinxPlayers(server);
        class_5250 subtitle;
        if (jinxes.isEmpty()) {
            subtitle = class_2561.method_43473()
                    .method_10852(JinxText.muted("游戏开始！"))
                    .method_10852(JinxText.warn(" 当前未指定倒霉蛋。"));
        } else if (jinxes.size() == 1) {
            subtitle = class_2561.method_43473()
                    .method_10852(JinxText.muted("当前倒霉蛋："))
                    .method_10852(JinxText.player(jinxes.getFirst()));
        } else {
            subtitle = class_2561.method_43473()
                    .method_10852(JinxText.muted("当前倒霉蛋（"))
                    .method_10852(JinxText.gold(String.valueOf(jinxes.size())))
                    .method_10852(JinxText.muted(" 人）："));
            for (int i = 0; i < jinxes.size(); i++) {
                if (i > 0) {
                    subtitle.method_10852(JinxText.muted("、"));
                }
                subtitle.method_10852(JinxText.player(jinxes.get(i)));
            }
        }

        JinxFeedback.broadcastTitle(
                server,
                JinxText.game("倒霉蛋游戏"),
                subtitle,
                10,
                70,
                20
        );
        for (class_3222 p : server.method_3760().method_14571()) {
            JinxFeedback.playSound(p, class_3417.field_14671, 0.15F, 1.6F);
        }
    }

    private static int executeStatus(class_2168 source) {
        class_5250 stateLine = class_2561.method_43473()
                .method_10852(JinxText.accent("状态 "))
                .method_10852(JinxText.muted("│ "))
                .method_10852(JinxText.game("游戏 "))
                .method_10852(JinxGameState.isStarted() ? JinxText.good("已开启") : JinxText.warn("未开启"))
                .method_10852(JinxText.muted(" │ "))
                .method_10852(JinxText.game("倒霉蛋 "));

        List<class_3222> jinxes = JinxGameState.getJinxPlayers(source.method_9211());
        if (jinxes.isEmpty()) {
            stateLine.method_10852(JinxText.muted("无"));
        } else {
            for (int i = 0; i < jinxes.size(); i++) {
                if (i > 0) {
                    stateLine.method_10852(JinxText.muted("、"));
                }
                stateLine.method_10852(JinxText.player(jinxes.get(i)));
            }
        }

        stateLine.method_10852(JinxText.muted(" │ "))
                .method_10852(JinxText.game("交互飞升 "))
                .method_10852(JinxFeatureFlags.isScreenLiftEnabled() ? JinxText.good("开") : JinxText.muted("关"));

        class_5250 finalLine = stateLine;
        source.method_9226(() -> finalLine, false);
        return 1;
    }

    private static int executeScreenLiftQuery(class_2168 source) {
        boolean on = JinxFeatureFlags.isScreenLiftEnabled();
        source.method_9226(() -> class_2561.method_43473()
                .method_10852(JinxText.linePrefix("倒霉蛋"))
                .method_10852(JinxText.muted("交互飞升："))
                .method_10852(on ? JinxText.good("开启 ") : JinxText.warn("关闭 "))
                .method_10852(JinxText.muted("("))
                .method_10852(JinxText.accent(Boolean.toString(on)))
                .method_10852(JinxText.muted(")")), false);
        return 1;
    }

    private static int executeScreenLiftSet(class_2168 source, boolean enabled) {
        JinxFeatureFlags.setScreenLiftEnabled(enabled);
        source.method_9226(() -> class_2561.method_43473()
                .method_10852(JinxText.good("已" + (enabled ? "开启" : "关闭") + " "))
                .method_10852(JinxText.accent("交互飞升"))
                .method_10852(JinxText.muted("（倒霉蛋打开容器界面时的抬升效果）。")), true);
        return enabled ? 1 : 0;
    }

    private static int executeSetByPlayer(class_2168 source, class_3222 target) {
        JinxGameState.assignJinx(source.method_9211(), target);
        source.method_9226(() -> class_2561.method_43473()
                .method_10852(JinxText.accent("已设置唯一倒霉蛋："))
                .method_10852(JinxText.player(target)), true);
        JinxFeedback.actionBar(
                target,
                class_2561.method_43473()
                        .method_10852(JinxText.game("管理员"))
                        .method_10852(JinxText.muted(" 将你设为 "))
                        .method_10852(JinxText.warn("唯一倒霉蛋"))
                        .method_10852(JinxText.muted("！"))
        );
        JinxFeedback.playSound(target, class_3417.field_14627, 0.6F, 0.8F);
        return 1;
    }
}
