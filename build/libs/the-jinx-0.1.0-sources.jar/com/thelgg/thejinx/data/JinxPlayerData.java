package com.thelgg.thejinx.data;

import net.minecraft.class_1657;

public final class JinxPlayerData {
    private JinxPlayerData() {
    }

    public static JinxPlayerDataComponent get(class_1657 player) {
        return JinxEntityComponents.get(player);
    }
}
