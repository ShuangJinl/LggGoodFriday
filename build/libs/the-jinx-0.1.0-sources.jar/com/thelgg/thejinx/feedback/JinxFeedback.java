package com.thelgg.thejinx.feedback;

import com.thelgg.thejinx.data.LimbPart;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5888;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;

public final class JinxFeedback {
    private JinxFeedback() {
    }

    public static void actionBar(class_3222 player, class_2561 message) {
        player.method_43502(message, true);
    }

    public static void chat(class_3222 player, class_2561 message) {
        player.method_7353(message, false);
    }

    public static void broadcastChat(MinecraftServer server, class_2561 message) {
        for (class_3222 p : server.method_3760().method_14571()) {
            p.method_7353(message, false);
        }
    }

    public static void playSound(class_3222 player, class_3414 sound, float volume, float pitch) {
        if (!(player.method_51469() instanceof class_3218 world)) {
            return;
        }
        world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), sound, class_3419.field_15248, volume, pitch);
    }

    public static void playSoundAt(class_3218 world, double x, double y, double z, class_3414 sound, float volume, float pitch) {
        world.method_43128(null, x, y, z, sound, class_3419.field_15248, volume, pitch);
    }

    public static void showTitle(class_3222 player, class_2561 title, class_2561 subtitle, int fadeIn, int stay, int fadeOut) {
        player.field_13987.method_14364(new class_5905(fadeIn, stay, fadeOut));
        player.field_13987.method_14364(new class_5903(subtitle));
        player.field_13987.method_14364(new class_5904(title));
    }

    public static void broadcastTitle(MinecraftServer server, class_2561 title, class_2561 subtitle, int fadeIn, int stay, int fadeOut) {
        for (class_3222 p : server.method_3760().method_14571()) {
            showTitle(p, title, subtitle, fadeIn, stay, fadeOut);
        }
    }

    public static void clearTitle(class_3222 player, boolean reset) {
        player.field_13987.method_14364(new class_5888(reset));
    }

    public static class_2561 limbDisplayName(LimbPart part) {
        return switch (part) {
            case HEAD -> class_2561.method_43470("头部").method_27695(class_124.field_1061, class_124.field_1067);
            case LEFT_ARM -> class_2561.method_43470("左臂").method_27692(class_124.field_1065);
            case RIGHT_ARM -> class_2561.method_43470("右臂").method_27692(class_124.field_1054);
            case LEFT_LEG -> class_2561.method_43470("左腿").method_27692(class_124.field_1075);
            case RIGHT_LEG -> class_2561.method_43470("右腿").method_27692(class_124.field_1062);
        };
    }
}
