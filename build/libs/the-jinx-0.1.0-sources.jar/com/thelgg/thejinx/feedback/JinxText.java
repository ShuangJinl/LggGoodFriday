package com.thelgg.thejinx.feedback;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

/**
 * 统一的中文提示配色与样式（动作栏 / 聊天 / 标题片段）。
 */
public final class JinxText {
    public static final class_2583 STYLE_GAME = class_2583.field_24360.method_10977(class_124.field_1076).method_10982(true);
    public static final class_2583 STYLE_ACCENT = class_2583.field_24360.method_10977(class_124.field_1075);
    public static final class_2583 STYLE_WARN = class_2583.field_24360.method_10977(class_124.field_1061);
    public static final class_2583 STYLE_GOOD = class_2583.field_24360.method_10977(class_124.field_1060);
    public static final class_2583 STYLE_MUTED = class_2583.field_24360.method_10977(class_124.field_1080);
    public static final class_2583 STYLE_GOLD = class_2583.field_24360.method_10977(class_124.field_1065);
    public static final class_2583 STYLE_YELLOW = class_2583.field_24360.method_10977(class_124.field_1054);

    private JinxText() {
    }

    public static class_5250 game(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_GAME);
    }

    public static class_5250 accent(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_ACCENT);
    }

    public static class_5250 warn(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_WARN);
    }

    public static class_5250 good(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_GOOD);
    }

    public static class_5250 muted(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_MUTED);
    }

    public static class_5250 gold(String content) {
        return class_2561.method_43470(content).method_10862(STYLE_GOLD);
    }

    /** 玩家显示名（保留队伍前缀等）。 */
    public static class_2561 player(class_3222 player) {
        return player.method_5476().method_27661();
    }

    public static class_5250 linePrefix(String label) {
        return class_2561.method_43473()
                .method_10852(class_2561.method_43470("「").method_10862(STYLE_MUTED))
                .method_10852(class_2561.method_43470(label).method_10862(STYLE_GAME))
                .method_10852(class_2561.method_43470("」 ").method_10862(STYLE_MUTED));
    }
}
