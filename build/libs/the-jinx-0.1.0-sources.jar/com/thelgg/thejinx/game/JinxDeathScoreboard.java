package com.thelgg.thejinx.game;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_274;
import net.minecraft.class_2995;
import net.minecraft.class_8646;
import net.minecraft.server.MinecraftServer;

/**
 * 游戏开始时在侧边栏显示“死亡次数”榜，游戏结束时移除。
 */
public final class JinxDeathScoreboard {
    public static final String OBJECTIVE_ID = "thejinx_deaths";

    private JinxDeathScoreboard() {
    }

    public static void show(MinecraftServer server) {
        class_2995 scoreboard = server.method_3845();
        unsetOurSidebarIfPresent(scoreboard);
        class_266 objective = scoreboard.method_1168(
                OBJECTIVE_ID,
                class_274.field_1456,
                class_2561.method_43470("死亡榜").method_27695(class_124.field_1061, class_124.field_1067),
                class_274.field_1456.method_1227(),
                false,
                null
        );
        scoreboard.method_1158(class_8646.field_45157, objective);
    }

    public static void hide(MinecraftServer server) {
        class_2995 scoreboard = server.method_3845();
        unsetOurSidebarIfPresent(scoreboard);
        class_266 objective = scoreboard.method_1170(OBJECTIVE_ID);
        if (objective != null) {
            scoreboard.method_1194(objective);
        }
    }

    private static void unsetOurSidebarIfPresent(class_2995 scoreboard) {
        class_266 slotObjective = scoreboard.method_1189(class_8646.field_45157);
        if (slotObjective != null && OBJECTIVE_ID.equals(slotObjective.method_1113())) {
            scoreboard.method_1158(class_8646.field_45157, null);
        }
    }
}
