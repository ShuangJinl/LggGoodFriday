package com.thelgg.thejinx.item;

import net.minecraft.class_1792;

public class AssimilationItem extends class_1792 {
    public AssimilationItem(class_1793 settings) {
        super(settings);
    }
}
