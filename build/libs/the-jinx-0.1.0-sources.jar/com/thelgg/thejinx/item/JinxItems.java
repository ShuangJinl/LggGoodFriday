package com.thelgg.thejinx.item;

import com.thelgg.thejinx.TheJinxMod;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class JinxItems {
    public static class_1792 ASSIMILATION;

    private JinxItems() {
    }

    public static void register() {
        class_2960 id = class_2960.method_60655(TheJinxMod.MOD_ID, "assimilation");
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
        ASSIMILATION = class_2378.method_10230(
                class_7923.field_41178,
                id,
                new AssimilationItem(new class_1792.class_1793().method_7889(1).method_63686(key))
        );
    }
}
