package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.data.JinxPlayerDataComponent;
import com.thelgg.thejinx.game.JinxGameState;
import com.thelgg.thejinx.item.JinxItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.server.MinecraftServer;

public final class AssimilationMechanic {
    private static final int ASSIMILATION_DEATH_THRESHOLD = 100;

    private AssimilationMechanic() {
    }

    public static void register() {
        AttackEntityCallback.EVENT.register(AssimilationMechanic::onAttackEntity);
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (entity instanceof class_3222 player) {
                onPlayerDeath(player);
            }
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> onAfterRespawn(newPlayer));
    }

    private static class_1269 onAttackEntity(class_1657 attacker, class_1937 world, net.minecraft.class_1268 hand, net.minecraft.class_1297 entity, net.minecraft.class_3966 hitResult) {
        if (world.method_8608()
                || !(attacker instanceof class_3222 sourcePlayer)
                || !(entity instanceof class_3222 targetPlayer)) {
            return class_1269.field_5811;
        }

        class_1799 stack = sourcePlayer.method_6047();
        if (!stack.method_31574(JinxItems.ASSIMILATION)) {
            return class_1269.field_5811;
        }

        if (sourcePlayer.method_5667().equals(targetPlayer.method_5667())) {
            return class_1269.field_5811;
        }

        if (!JinxGameState.isStarted() || !JinxRuleHelper.isActiveJinx(sourcePlayer)) {
            return class_1269.field_5811;
        }

        MinecraftServer server = ((net.minecraft.class_3218) sourcePlayer.method_51469()).method_8503();

        if (JinxPlayerData.get(targetPlayer).isJinx()) {
            sourcePlayer.method_7353(
                    class_2561.method_43473()
                            .method_10852(JinxText.linePrefix("同化"))
                            .method_10852(JinxText.player(targetPlayer))
                            .method_10852(JinxText.muted(" 已经是倒霉蛋了。")),
                    false
            );
            return class_1269.field_5812;
        }

        JinxGameState.promoteToJinx(server, targetPlayer);
        targetPlayer.method_6016(class_1294.field_5901);

        JinxPlayerDataComponent sourceData = JinxPlayerData.get(sourcePlayer);
        sourceData.setUsedAssimilation(true);
        sourceData.setShouldRegrantAssimilation(false);

        stack.method_7934(1);

        sourcePlayer.method_7353(
                class_2561.method_43473()
                        .method_10852(JinxText.linePrefix("同化"))
                        .method_10852(JinxText.good("成功 "))
                        .method_10852(JinxText.player(targetPlayer))
                        .method_10852(JinxText.muted(" 已成为倒霉蛋；你们 "))
                        .method_10852(JinxText.accent("同时"))
                        .method_10852(JinxText.muted(" 承受倒霉蛋规则。")),
                false
        );
        targetPlayer.method_7353(
                class_2561.method_43473()
                        .method_10852(JinxText.linePrefix("同化"))
                        .method_10852(JinxText.warn("你已成为倒霉蛋！"))
                        .method_10852(JinxText.muted("（与 "))
                        .method_10852(JinxText.player(sourcePlayer))
                        .method_10852(JinxText.muted(" 状态同步）")),
                false
        );
        JinxFeedback.playSound(sourcePlayer, class_3417.field_14858, 0.45F, 1.15F);
        JinxFeedback.playSound(targetPlayer, class_3417.field_14858, 0.55F, 1.05F);
        return class_1269.field_5812;
    }

    private static void onPlayerDeath(class_3222 player) {
        if (!JinxRuleHelper.isActiveJinx(player)) {
            return;
        }

        JinxPlayerDataComponent data = JinxPlayerData.get(player);
        data.incrementJinxDeaths();
        if (data.getJinxDeaths() >= ASSIMILATION_DEATH_THRESHOLD && !data.hasUsedAssimilation()) {
            data.setShouldRegrantAssimilation(true);
            ensureAssimilationItem(player);
        }
    }

    private static void onAfterRespawn(class_3222 player) {
        if (!JinxRuleHelper.isActiveJinx(player)) {
            return;
        }

        JinxPlayerDataComponent data = JinxPlayerData.get(player);
        if (data.getJinxDeaths() >= ASSIMILATION_DEATH_THRESHOLD
                && !data.hasUsedAssimilation()
                && data.shouldRegrantAssimilation()) {
            ensureAssimilationItem(player);
        }
    }

    private static void ensureAssimilationItem(class_3222 player) {
        if (player.method_31548().method_43256(stack -> stack.method_31574(JinxItems.ASSIMILATION))) {
            return;
        }

        class_1799 assimilationStack = new class_1799(JinxItems.ASSIMILATION);
        if (!player.method_7270(assimilationStack)) {
            player.method_7328(assimilationStack, false);
        }
        JinxFeedback.chat(
                player,
                class_2561.method_43473()
                        .method_10852(JinxText.linePrefix("倒霉蛋"))
                        .method_10852(JinxText.gold("同化之卵 "))
                        .method_10852(JinxText.muted("— 用其 "))
                        .method_10852(JinxText.accent("攻击一名玩家"))
                        .method_10852(JinxText.muted(" 可将其 "))
                        .method_10852(JinxText.warn("同步"))
                        .method_10852(JinxText.muted(" 为倒霉蛋（你不会失去身份）；丢弃会消失。"))
        );
        JinxFeedback.playSound(player, class_3417.field_23116, 0.35F, 1.25F);
    }
}
