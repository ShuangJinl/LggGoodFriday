package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.game.JinxGameState;
import java.util.List;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;

public final class GlobalFatigueAndDeathFiestaMechanic {
    private static final int FIESTA_DURATION_TICKS = 20 * 30;
    private static final int FATIGUE_REFRESH_INTERVAL_TICKS = 20;
    private static final int FATIGUE_DURATION_TICKS = 20 * 6;
    private static final int FATIGUE_AMPLIFIER = 4; // 挖掘疲劳 V

    private static int fiestaTicksRemaining = 0;
    private static int fatigueRefreshCooldown = 0;
    private static boolean fatigueReturnAnnounced = true;

    private static final List<class_6880<class_1291>> POSITIVE_EFFECT_POOL = List.of(
            class_1294.field_5904,
            class_1294.field_5917,
            class_1294.field_5910,
            class_1294.field_5907,
            class_1294.field_5924,
            class_1294.field_5913,
            class_1294.field_5925,
            class_1294.field_5918
    );

    private GlobalFatigueAndDeathFiestaMechanic() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(GlobalFatigueAndDeathFiestaMechanic::onServerTick);
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof class_3222 deadPlayer)) {
                return;
            }
            onPlayerDeath(deadPlayer);
        });
    }

    private static void onServerTick(MinecraftServer server) {
        if (!JinxGameState.isStarted()) {
            fiestaTicksRemaining = 0;
            fatigueReturnAnnounced = true;
            return;
        }

        if (fiestaTicksRemaining > 0) {
            fiestaTicksRemaining--;
            if (fiestaTicksRemaining == 0) {
                applyFatigueToNonJinxPlayers(server);
                if (!fatigueReturnAnnounced) {
                    JinxFeedback.broadcastChat(server, class_2561.method_43473()
                            .method_10852(JinxText.game("死亡狂欢 "))
                            .method_10852(JinxText.muted("结束：全员重新获得 "))
                            .method_10852(JinxText.warn("挖掘疲劳 V"))
                            .method_10852(JinxText.muted("（倒霉蛋除外）。")));
                    for (class_3222 p : server.method_3760().method_14571()) {
                        JinxFeedback.playSound(p, class_3417.field_15008, 0.4F, 0.85F);
                    }
                    fatigueReturnAnnounced = true;
                }
            }
            return;
        }

        if (fatigueRefreshCooldown > 0) {
            fatigueRefreshCooldown--;
        } else {
            applyFatigueToNonJinxPlayers(server);
            fatigueRefreshCooldown = FATIGUE_REFRESH_INTERVAL_TICKS;
        }
    }

    private static void onPlayerDeath(class_3222 deadPlayer) {
        if (!JinxRuleHelper.isActiveJinx(deadPlayer)) {
            return;
        }

        // 狂欢窗口内再次死亡不重置计时，也不重复发奖励。
        if (fiestaTicksRemaining > 0) {
            return;
        }

        fiestaTicksRemaining = FIESTA_DURATION_TICKS;
        fatigueReturnAnnounced = false;
        net.minecraft.server.MinecraftServer server = ((net.minecraft.class_3218) deadPlayer.method_51469()).method_8503();
        clearFatigueForAll(server);
        grantRandomPositiveEffects(server);
        class_5250 deathMsg = class_2561.method_43473()
                .method_10852(JinxText.linePrefix("狂欢"))
                .method_10852(JinxText.player(deadPlayer))
                .method_10852(JinxText.muted(" 阵亡：开启 "))
                .method_10852(JinxText.warn("30 秒"))
                .method_10852(JinxText.accent("死亡狂欢"))
                .method_10852(JinxText.muted("！"))
                .method_10852(JinxText.good(" 挖掘疲劳已清除，全员随机增益。"));
        JinxFeedback.broadcastChat(server, deathMsg);
        for (class_3222 p : server.method_3760().method_14571()) {
            JinxFeedback.playSound(p, class_3417.field_15195, 0.5F, 1.0F);
        }
    }

    private static void applyFatigueToNonJinxPlayers(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            if (JinxGameState.isJinx(player)) {
                player.method_6016(class_1294.field_5901);
                continue;
            }

            player.method_6092(new class_1293(
                    class_1294.field_5901,
                    FATIGUE_DURATION_TICKS,
                    FATIGUE_AMPLIFIER,
                    true,
                    false,
                    true
            ));
        }
    }

    private static void clearFatigueForAll(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            player.method_6016(class_1294.field_5901);
        }
    }

    private static void grantRandomPositiveEffects(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            class_6880<class_1291> effect = POSITIVE_EFFECT_POOL.get(server.method_30002().field_9229.method_43048(POSITIVE_EFFECT_POOL.size()));
            player.method_6092(new class_1293(effect, FIESTA_DURATION_TICKS, 0, true, true, true));
        }
    }
}
