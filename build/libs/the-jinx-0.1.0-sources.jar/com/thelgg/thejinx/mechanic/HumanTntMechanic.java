package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_8103;

public final class HumanTntMechanic {
    private static final float TNT_POWER = 4.0F;
    /**
     * 原版爆炸对“爆炸中心实体”常不结算伤害；在 {@link class_3218#method_8437} 之后对倒霉蛋补一次同类型伤害，
     * 数值按 TNT 威力近似，仍走护甲/抗性/伤害事件。
     */
    private static final float HUMAN_TNT_SELF_EXPLOSION_DAMAGE = TNT_POWER * 3.5F;
    private static final double CARRY_HEIGHT_OFFSET = 2.05D;
    private static final long LAUNCH_COLLISION_GRACE_TICKS = 4L;
    private static final double LAUNCH_HORIZONTAL_SPEED = 7.5D;
    private static final double LAUNCH_VERTICAL_BOOST = 1.75D;
    private static final double MIN_HORIZONTAL_LOOK_LEN = 0.12D;
    private static final double LAUNCH_SPAWN_FORWARD_OFFSET = 2.4D;
    private static final double LAUNCH_SPAWN_UP_OFFSET = 2.0D;
    private static final long LAUNCH_REINFORCE_TICKS = 10L;
    private static final double LAUNCH_REINFORCE_FORWARD_NUDGE = 0.45D;
    private static final double LAUNCH_REINFORCE_UP_NUDGE = 0.08D;
    private static final Map<UUID, UUID> CARRIED_JINX_TO_CARRIER = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAUNCHED_AT_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, class_243> PENDING_REAPPLY_VELOCITY = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> PENDING_REAPPLY_UNTIL_TICK = new ConcurrentHashMap<>();
    private static final Map<UUID, class_243> PENDING_REAPPLY_DIRECTION = new ConcurrentHashMap<>();

    private HumanTntMechanic() {
    }

    public static void register() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(HumanTntMechanic::allowDamageWhileCarried);
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> onUseEntity(player, world, entity));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                followCarrierIfNeeded(player);
                reapplyLaunchVelocityIfNeeded(player);
                checkLaunchedCollision(player);
            }
        });
    }

    private static boolean allowDamageWhileCarried(class_1309 entity, class_1282 source, float amount) {
        if (!(entity instanceof class_3222 player)) {
            return true;
        }
        if (!JinxRuleHelper.isActiveJinx(player) || !isJinxBeingCarried(player)) {
            return true;
        }
        return !source.method_48789(class_8103.field_42250);
    }

    private static class_1269 onUseEntity(net.minecraft.class_1657 player, class_1937 world, class_1297 entity) {
        if (world.method_8608() || !(player instanceof class_3222 actor)) {
            return class_1269.field_5811;
        }

        if (!(entity instanceof class_3222 target)) {
            return class_1269.field_5811;
        }

        if (!JinxRuleHelper.isActiveJinx(target)) {
            return class_1269.field_5811;
        }

        if (actor.equals(target) || isJinxBeingCarried(target)) {
            return class_1269.field_5811;
        }

        boolean mounted = target.method_5873(actor, true, true);
        if (!mounted) {
            // 部分场景下玩家不能稳定挂载，兜底为“跟随抬起”。
            CARRIED_JINX_TO_CARRIER.put(target.method_5667(), actor.method_5667());
        }
        JinxFeedback.actionBar(actor, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("人体TNT"))
                .method_10852(JinxText.good("你已举起 "))
                .method_10852(JinxText.player(target)));
        JinxFeedback.actionBar(target, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("人体TNT"))
                .method_10852(JinxText.warn("你已被 "))
                .method_10852(JinxText.player(actor))
                .method_10852(JinxText.muted(" 举起")));
        JinxFeedback.playSound(actor, class_3417.field_15095, 0.55F, 0.9F);
        JinxFeedback.playSound(target, class_3417.field_15095, 0.55F, 1.1F);
        return class_1269.field_5812;
    }

    public static void tryLaunchPassengerJinx(class_3222 actor) {
        for (class_1297 passenger : actor.method_5685()) {
            if (passenger instanceof class_3222 jinx && JinxRuleHelper.isActiveJinx(jinx)) {
                jinx.method_5848();
                launchJinx(actor, jinx);
                break;
            }
        }

        for (Map.Entry<UUID, UUID> entry : CARRIED_JINX_TO_CARRIER.entrySet()) {
            if (!entry.getValue().equals(actor.method_5667())) {
                continue;
            }

            class_3222 jinx = actor.method_51469().method_8503().method_3760().method_14602(entry.getKey());
            if (jinx == null || !JinxRuleHelper.isActiveJinx(jinx)) {
                CARRIED_JINX_TO_CARRIER.remove(entry.getKey());
                continue;
            }

            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            launchJinx(actor, jinx);
            break;
        }
    }

    public static boolean isJinxBeingCarried(class_3222 jinx) {
        if (jinx.method_5765()) {
            return true;
        }

        UUID carrierUuid = CARRIED_JINX_TO_CARRIER.get(jinx.method_5667());
        if (carrierUuid == null) {
            return false;
        }

        class_3222 carrier = jinx.method_51469().method_8503().method_3760().method_14602(carrierUuid);
        if (carrier == null || !carrier.method_5805() || !jinx.method_5805() || carrier.method_51469() != jinx.method_51469()) {
            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            return false;
        }

        // 兜底抓举超过范围视为失效，防止状态残留导致飞升一直被禁用。
        if (carrier.method_5858(jinx) > 16.0D) {
            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            return false;
        }
        return true;
    }

    private static class_243 computeLaunchVelocity(class_3222 actor) {
        class_243 horizontal = computeHorizontalLaunchDirection(actor);
        horizontal = horizontal.method_1029().method_1021(LAUNCH_HORIZONTAL_SPEED);
        return new class_243(horizontal.field_1352, LAUNCH_VERTICAL_BOOST, horizontal.field_1350);
    }

    private static class_243 computeHorizontalLaunchDirection(class_3222 actor) {
        class_243 look = actor.method_5720();
        class_243 horizontal = new class_243(look.field_1352, 0.0D, look.field_1350);
        if (horizontal.method_1027() < MIN_HORIZONTAL_LOOK_LEN * MIN_HORIZONTAL_LOOK_LEN) {
            horizontal = class_243.method_1030(0.0F, actor.method_36454());
        }
        return horizontal.method_1029();
    }

    private static void launchJinx(class_3222 actor, class_3222 jinx) {
        class_243 horizontalDir = computeHorizontalLaunchDirection(actor);
        class_243 spawnPos = new class_243(actor.method_23317(), actor.method_23318(), actor.method_23321())
                .method_1019(horizontalDir.method_1021(LAUNCH_SPAWN_FORWARD_OFFSET))
                .method_1031(0.0D, LAUNCH_SPAWN_UP_OFFSET, 0.0D);

        // 先前置到玩家前上方，避免“发射后落脚下”。
        jinx.method_5859(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350);
        class_243 launchVelocity = computeLaunchVelocity(actor);
        jinx.method_18799(launchVelocity);
        jinx.field_6017 = 0.0F;
        JinxPlayerData.get(jinx).setLaunchedAsHumanTnt(true);
        JinxFeedback.actionBar(actor, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("人体TNT"))
                .method_10852(JinxText.accent("已掷出 "))
                .method_10852(JinxText.player(jinx)));
        JinxFeedback.actionBar(jinx, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("人体TNT"))
                .method_10852(JinxText.warn("你被掷出！"))
                .method_10852(JinxText.muted(" 撞方块将 "))
                .method_10852(JinxText.gold("爆炸")));
        JinxFeedback.playSound(actor, class_3417.field_14702, 0.45F, 1.0F);
        JinxFeedback.playSound(jinx, class_3417.field_14702, 0.55F, 1.05F);
        long now = actor.method_51469().method_75260();
        LAUNCHED_AT_TICK.put(jinx.method_5667(), now);
        // 发射后短窗口内持续强化，减少“偶发没飞出去”的情况。
        PENDING_REAPPLY_VELOCITY.put(jinx.method_5667(), launchVelocity);
        PENDING_REAPPLY_DIRECTION.put(jinx.method_5667(), horizontalDir);
        PENDING_REAPPLY_UNTIL_TICK.put(jinx.method_5667(), now + LAUNCH_REINFORCE_TICKS);
    }

    private static void reapplyLaunchVelocityIfNeeded(class_3222 player) {
        Long applyUntil = PENDING_REAPPLY_UNTIL_TICK.get(player.method_5667());
        if (applyUntil == null) {
            return;
        }

        long now = player.method_51469().method_75260();
        if (now > applyUntil) {
            PENDING_REAPPLY_VELOCITY.remove(player.method_5667());
            PENDING_REAPPLY_DIRECTION.remove(player.method_5667());
            PENDING_REAPPLY_UNTIL_TICK.remove(player.method_5667());
            return;
        }

        class_243 velocity = PENDING_REAPPLY_VELOCITY.get(player.method_5667());
        class_243 direction = PENDING_REAPPLY_DIRECTION.get(player.method_5667());
        if (velocity == null || !JinxPlayerData.get(player).isLaunchedAsHumanTnt()) {
            PENDING_REAPPLY_VELOCITY.remove(player.method_5667());
            PENDING_REAPPLY_DIRECTION.remove(player.method_5667());
            PENDING_REAPPLY_UNTIL_TICK.remove(player.method_5667());
            return;
        }
        player.method_18799(velocity);
        if (direction != null) {
            player.method_5859(
                    player.method_23317() + direction.field_1352 * LAUNCH_REINFORCE_FORWARD_NUDGE,
                    player.method_23318() + LAUNCH_REINFORCE_UP_NUDGE,
                    player.method_23321() + direction.field_1350 * LAUNCH_REINFORCE_FORWARD_NUDGE
            );
        }
    }

    private static void followCarrierIfNeeded(class_3222 jinx) {
        UUID carrierUuid = CARRIED_JINX_TO_CARRIER.get(jinx.method_5667());
        if (carrierUuid == null) {
            return;
        }

        if (!JinxRuleHelper.isActiveJinx(jinx)) {
            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            return;
        }

        class_3222 carrier = jinx.method_51469().method_8503().method_3760().method_14602(carrierUuid);
        if (carrier == null || !carrier.method_5805() || !jinx.method_5805()) {
            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            return;
        }

        if (jinx.method_5765()) {
            CARRIED_JINX_TO_CARRIER.remove(jinx.method_5667());
            return;
        }

        jinx.method_5859(carrier.method_23317(), carrier.method_23318() + CARRY_HEIGHT_OFFSET, carrier.method_23321());
        jinx.method_18799(class_243.field_1353);
        jinx.field_6017 = 0.0F;
    }

    private static void checkLaunchedCollision(class_3222 player) {
        class_3218 serverWorld = (class_3218) player.method_51469();

        if (!JinxPlayerData.get(player).isLaunchedAsHumanTnt()) {
            LAUNCHED_AT_TICK.remove(player.method_5667());
            PENDING_REAPPLY_VELOCITY.remove(player.method_5667());
            PENDING_REAPPLY_DIRECTION.remove(player.method_5667());
            PENDING_REAPPLY_UNTIL_TICK.remove(player.method_5667());
            return;
        }

        long launchedAt = LAUNCHED_AT_TICK.getOrDefault(player.method_5667(), -1L);
        if (launchedAt >= 0L && serverWorld.method_75260() - launchedAt < LAUNCH_COLLISION_GRACE_TICKS) {
            return;
        }

        if (player.field_5976 || player.field_5992) {
            JinxFeedback.actionBar(player, class_2561.method_43473()
                    .method_10852(JinxText.linePrefix("人体TNT"))
                    .method_10852(JinxText.warn("撞击 "))
                    .method_10852(JinxText.gold("爆炸！")));
            // 不以倒霉蛋为爆炸实体：否则新版下常出现“爆炸源不吃伤害”，且易连带影响他人判定。
            class_1282 explosionDamage = serverWorld.method_48963().method_48819(null, null);
            serverWorld.method_55117(
                    null,
                    explosionDamage,
                    null,
                    player.method_23317(),
                    player.method_23318(),
                    player.method_23321(),
                    TNT_POWER,
                    false,
                    class_1937.class_7867.field_40891
            );
            if (player.method_5805()) {
                player.method_64397(serverWorld, explosionDamage, HUMAN_TNT_SELF_EXPLOSION_DAMAGE);
            }
            JinxPlayerData.get(player).setLaunchedAsHumanTnt(false);
            LAUNCHED_AT_TICK.remove(player.method_5667());
            PENDING_REAPPLY_VELOCITY.remove(player.method_5667());
            PENDING_REAPPLY_DIRECTION.remove(player.method_5667());
            PENDING_REAPPLY_UNTIL_TICK.remove(player.method_5667());
        }
    }
}
