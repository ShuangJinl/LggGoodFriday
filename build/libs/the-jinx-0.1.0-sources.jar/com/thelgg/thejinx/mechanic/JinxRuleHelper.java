package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.game.JinxGameState;
import net.minecraft.class_3222;

public final class JinxRuleHelper {
    private JinxRuleHelper() {
    }

    public static boolean isActiveJinx(class_3222 player) {
        return JinxGameState.isStarted() && JinxGameState.isJinx(player);
    }
}
