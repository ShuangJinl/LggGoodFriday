package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;

public final class OreTripleDropMechanic {
    private OreTripleDropMechanic() {
    }

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof class_3222 serverPlayer)) {
                return;
            }

            if (!JinxRuleHelper.isActiveJinx(serverPlayer)) {
                return;
            }

            if (!isOre(state)) {
                return;
            }

            spawnExtraDrops((class_3218) world, serverPlayer, pos, state, blockEntity);
            JinxFeedback.actionBar(serverPlayer, class_2561.method_43473()
                    .method_10852(JinxText.linePrefix("倒霉蛋"))
                    .method_10852(JinxText.gold("矿物三倍掉落 "))
                    .method_10852(JinxText.good("生效"))
                    .method_10852(JinxText.muted("（额外×2）")));
            JinxFeedback.playSound(serverPlayer, class_3417.field_26980, 0.6F, 1.25F);
        });
    }

    private static boolean isOre(class_2680 state) {
        return state.method_26164(ConventionalBlockTags.ORES);
    }

    private static void spawnExtraDrops(class_3218 world, class_3222 player, class_2338 pos, class_2680 state, class_2586 blockEntity) {
        // 原版已掉落 1 倍，这里额外掉 2 倍，最终达到 3 倍掉落。
        for (class_1799 stack : class_2248.method_9609(state, world, pos, blockEntity, player, player.method_6047())) {
            if (stack.method_7960()) {
                continue;
            }
            class_1799 extra = stack.method_7972();
            extra.method_7939(stack.method_7947() * 2);
            class_2248.method_9577(world, pos, extra);
        }
    }
}
