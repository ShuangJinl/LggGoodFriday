package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.game.JinxFeatureFlags;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1294;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;

public final class ScreenLiftAndGravityMechanic {
    private static final double LIFT_UP_SPEED = 0.92D;
    private static final double LIFT_DELTA_Y_PER_TICK = 0.24D;
    private static final double OPEN_IMPULSE_UP_SPEED = 1.15D;
    private static final double OPEN_IMPULSE_DELTA_Y = 0.38D;
    private static final long OPEN_IMPULSE_DURATION_TICKS = 5L;
    // 原版约 0.08/tick，下落五倍体感 => 额外施加 0.32（总计约 0.40）
    private static final double EXTRA_GRAVITY_PER_TICK = 0.32D;
    private static final Map<UUID, Long> OPEN_IMPULSE_UNTIL_TICK = new ConcurrentHashMap<>();

    private ScreenLiftAndGravityMechanic() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tickPlayer(player);
            }
        });
    }

    private static void tickPlayer(class_3222 player) {
        if (!JinxRuleHelper.isActiveJinx(player)) {
            player.method_5875(false);
            OPEN_IMPULSE_UNTIL_TICK.remove(player.method_5667());
            return;
        }

        if (HumanTntMechanic.isJinxBeingCarried(player)) {
            player.method_5875(false);
            OPEN_IMPULSE_UNTIL_TICK.remove(player.method_5667());
            return;
        }

        // 人体 TNT 飞行期间不要改写速度/坐标，否则与界面飞升同类：会在首几 tick 抹掉掷出初速度。
        if (JinxPlayerData.get(player).isLaunchedAsHumanTnt()) {
            player.method_5875(false);
            OPEN_IMPULSE_UNTIL_TICK.remove(player.method_5667());
            return;
        }

        if (JinxPlayerData.get(player).isScreenOpen()) {
            if (JinxFeatureFlags.isScreenLiftEnabled()) {
                long now = player.method_51469().method_75260();
                long openImpulseUntil = OPEN_IMPULSE_UNTIL_TICK.getOrDefault(player.method_5667(), -1L);
                boolean inOpenImpulseWindow = openImpulseUntil >= now;
                class_243 velocity = player.method_18798();
                // 直接抬升坐标 + 无重力，规避交互期间速度被其他逻辑覆盖的问题。
                player.method_5875(true);
                double deltaY = inOpenImpulseWindow ? OPEN_IMPULSE_DELTA_Y : LIFT_DELTA_Y_PER_TICK;
                double upSpeed = inOpenImpulseWindow ? OPEN_IMPULSE_UP_SPEED : LIFT_UP_SPEED;
                player.method_5859(player.method_23317(), player.method_23318() + deltaY, player.method_23321());
                player.method_18800(velocity.field_1352 * 0.6D, upSpeed, velocity.field_1350 * 0.6D);
                player.field_6017 = 0.0F;
                return;
            }
            player.method_5875(false);
            OPEN_IMPULSE_UNTIL_TICK.remove(player.method_5667());
        } else {
            player.method_5875(false);
            OPEN_IMPULSE_UNTIL_TICK.remove(player.method_5667());
        }

        if (!player.method_24828()
                && player.method_18798().field_1351 < 0.0D
                && !player.method_6059(class_1294.field_5906)) {
            class_243 velocity = player.method_18798();
            player.method_18800(velocity.field_1352, velocity.field_1351 - EXTRA_GRAVITY_PER_TICK, velocity.field_1350);
        }
    }

    public static void onScreenStateSync(class_3222 player, boolean oldState, boolean newState) {
        if (!JinxRuleHelper.isActiveJinx(player)) {
            return;
        }
        if (!oldState && newState) {
            if (JinxFeatureFlags.isScreenLiftEnabled()) {
                long now = player.method_51469().method_75260();
                OPEN_IMPULSE_UNTIL_TICK.put(player.method_5667(), now + OPEN_IMPULSE_DURATION_TICKS);
                class_243 velocity = player.method_18798();
                player.method_18800(velocity.field_1352 * 0.6D, OPEN_IMPULSE_UP_SPEED, velocity.field_1350 * 0.6D);
                JinxFeedback.actionBar(player, class_2561.method_43473()
                        .method_10852(JinxText.linePrefix("倒霉蛋"))
                        .method_10852(JinxText.accent("界面飞升 "))
                        .method_10852(JinxText.good("已激活")));
                JinxFeedback.playSound(player, class_3417.field_14891, 0.35F, 1.5F);
            }
            return;
        }
        if (!oldState || newState) {
            return;
        }
    }
}
