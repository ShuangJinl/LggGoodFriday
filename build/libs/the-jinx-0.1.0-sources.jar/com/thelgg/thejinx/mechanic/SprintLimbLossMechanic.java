package com.thelgg.thejinx.mechanic;

import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.data.JinxPlayerDataComponent;
import com.thelgg.thejinx.data.LimbPart;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;

public final class SprintLimbLossMechanic {
    private static final int LIMB_STEP_TICKS = 20 * 5;

    private SprintLimbLossMechanic() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tickPlayer(player);
            }
        });
    }

    private static void tickPlayer(class_3222 player) {
        if (!JinxRuleHelper.isActiveJinx(player)) {
            return;
        }

        JinxPlayerDataComponent data = JinxPlayerData.get(player);
        if (player.method_5624()) {
            data.setRecoveryProgressTicks(0);
            long sprintTicks = data.getSprintProgressTicks() + 1;
            if (sprintTicks >= LIMB_STEP_TICKS) {
                sprintTicks = 0;
                loseRandomLimb(player, data);
            }
            data.setSprintProgressTicks(sprintTicks);
        } else {
            data.setSprintProgressTicks(0);
            long recoveryTicks = data.getRecoveryProgressTicks() + 1;
            if (recoveryTicks >= LIMB_STEP_TICKS) {
                recoveryTicks = 0;
                recoverRandomLimb(player, data);
            }
            data.setRecoveryProgressTicks(recoveryTicks);
        }

        applyDebuffs(player, data);
    }

    private static void loseRandomLimb(class_3222 player, JinxPlayerDataComponent data) {
        List<LimbPart> candidates = new ArrayList<>();
        for (LimbPart part : LimbPart.values()) {
            if (!data.hasMissingPart(part)) {
                candidates.add(part);
            }
        }
        if (candidates.isEmpty()) {
            return;
        }

        LimbPart chosen = candidates.get(((net.minecraft.class_3218) player.method_51469()).field_9229.method_43048(candidates.size()));
        data.setMissingPart(chosen, true);
        player.method_18382();
        JinxFeedback.actionBar(player, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("断肢"))
                .method_10852(JinxText.warn("失去 "))
                .method_10852(JinxFeedback.limbDisplayName(chosen)));
        JinxFeedback.playSound(player, class_3417.field_15115, 0.55F, 0.85F);
    }

    private static void recoverRandomLimb(class_3222 player, JinxPlayerDataComponent data) {
        List<LimbPart> candidates = new ArrayList<>(data.getMissingParts());
        if (candidates.isEmpty()) {
            return;
        }

        LimbPart chosen = candidates.get(((net.minecraft.class_3218) player.method_51469()).field_9229.method_43048(candidates.size()));
        data.setMissingPart(chosen, false);
        player.method_18382();
        JinxFeedback.actionBar(player, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("断肢"))
                .method_10852(JinxText.good("恢复 "))
                .method_10852(JinxFeedback.limbDisplayName(chosen)));
        JinxFeedback.playSound(player, class_3417.field_14627, 0.5F, 1.15F);
    }

    private static void applyDebuffs(class_3222 player, JinxPlayerDataComponent data) {
        int missingArms = 0;
        int missingLegs = 0;
        boolean missingHead = data.hasMissingPart(LimbPart.HEAD);

        if (data.hasMissingPart(LimbPart.LEFT_ARM)) {
            missingArms++;
        }
        if (data.hasMissingPart(LimbPart.RIGHT_ARM)) {
            missingArms++;
        }
        if (data.hasMissingPart(LimbPart.LEFT_LEG)) {
            missingLegs++;
        }
        if (data.hasMissingPart(LimbPart.RIGHT_LEG)) {
            missingLegs++;
        }

        if (missingHead) {
            player.method_6092(new class_1293(class_1294.field_5916, 40, 0, true, false, true));
        } else {
            player.method_6016(class_1294.field_5916);
        }

        if (missingArms <= 0) {
            player.method_6016(class_1294.field_5901);
            player.method_6016(class_1294.field_5911);
        } else {
            int armAmplifier = missingArms >= 2 ? 1 : 0;
            player.method_6092(new class_1293(class_1294.field_5901, 40, armAmplifier, true, false, true));
            player.method_6092(new class_1293(class_1294.field_5911, 40, armAmplifier, true, false, true));
        }

        if (missingLegs <= 0) {
            player.method_6016(class_1294.field_5909);
        } else {
            int legAmplifier = missingLegs >= 2 ? 2 : 0;
            player.method_6092(new class_1293(class_1294.field_5909, 40, legAmplifier, true, false, true));
        }
    }
}
