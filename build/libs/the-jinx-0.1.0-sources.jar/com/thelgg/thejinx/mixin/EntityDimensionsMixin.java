package com.thelgg.thejinx.mixin;

import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.data.LimbPart;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityDimensionsMixin {
    @Inject(method = "getDimensions(Lnet/minecraft/entity/EntityPose;)Lnet/minecraft/entity/EntityDimensions;", at = @At("HEAD"), cancellable = true)
    private void theJinx$modifyDimensionsForLegLoss(class_4050 pose, CallbackInfoReturnable<class_4048> cir) {
        class_1297 self = (class_1297) (Object) this;
        if (!(self instanceof class_1657 player)) {
            return;
        }

        int missingLegs = 0;
        if (JinxPlayerData.get(player).hasMissingPart(LimbPart.LEFT_LEG)) {
            missingLegs++;
        }
        if (JinxPlayerData.get(player).hasMissingPart(LimbPart.RIGHT_LEG)) {
            missingLegs++;
        }

        if (missingLegs <= 0) {
            return;
        }

        // 丢失腿部后降低碰撞箱高度（视觉上更接地）
        if (missingLegs >= 2) {
            cir.setReturnValue(class_4048.method_18384(0.6F, 0.8F));
        } else {
            cir.setReturnValue(class_4048.method_18384(0.6F, 1.5F));
        }
    }
}

