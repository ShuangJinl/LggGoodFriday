package com.thelgg.thejinx.mixin;

import com.thelgg.thejinx.item.JinxItems;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityAssimilationMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void theJinx$discardAssimilationDrop(CallbackInfo ci) {
        class_1542 self = (class_1542) (Object) this;
        class_1937 world = self.method_73183();
        if (world.method_8608()) {
            return;
        }

        if (JinxItems.ASSIMILATION != null && self.method_6983().method_31574(JinxItems.ASSIMILATION)) {
            self.method_31472();
            ci.cancel();
        }
    }
}

