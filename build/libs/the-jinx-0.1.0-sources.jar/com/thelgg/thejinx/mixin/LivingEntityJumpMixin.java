package com.thelgg.thejinx.mixin;

import com.thelgg.thejinx.feedback.JinxFeedback;
import com.thelgg.thejinx.feedback.JinxText;
import com.thelgg.thejinx.mechanic.JinxRuleHelper;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityJumpMixin {
    @Inject(method = "jump", at = @At("TAIL"))
    private void theJinx$spawnLightningOnJump(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!(self.method_73183() instanceof class_3218 serverWorld)) {
            return;
        }

        if (!(self instanceof class_3222 player)) {
            return;
        }

        if (!JinxRuleHelper.isActiveJinx(player)) {
            return;
        }

        class_1538 lightning = class_1299.field_6112.method_5883(serverWorld, class_3730.field_16461);
        if (lightning == null) {
            return;
        }
        lightning.method_24203(player.method_23317(), player.method_23318(), player.method_23321());
        serverWorld.method_8649(lightning);
        JinxFeedback.actionBar(player, class_2561.method_43473()
                .method_10852(JinxText.linePrefix("倒霉蛋"))
                .method_10852(JinxText.warn("跳跃 "))
                .method_10852(JinxText.accent("召唤雷击！")));
        JinxFeedback.playSound(player, class_3417.field_14865, 0.3F, 1.4F);
    }
}
