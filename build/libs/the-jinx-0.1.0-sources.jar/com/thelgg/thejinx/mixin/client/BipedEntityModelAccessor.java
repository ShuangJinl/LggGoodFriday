package com.thelgg.thejinx.mixin.client;

import net.minecraft.class_572;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_572.class)
public interface BipedEntityModelAccessor {
    @Accessor("head")
    class_630 theJinx$getHead();

    @Accessor("hat")
    class_630 theJinx$getHat();

    @Accessor("body")
    class_630 theJinx$getBody();

    @Accessor("leftArm")
    class_630 theJinx$getLeftArm();

    @Accessor("rightArm")
    class_630 theJinx$getRightArm();

    @Accessor("leftLeg")
    class_630 theJinx$getLeftLeg();

    @Accessor("rightLeg")
    class_630 theJinx$getRightLeg();
}
