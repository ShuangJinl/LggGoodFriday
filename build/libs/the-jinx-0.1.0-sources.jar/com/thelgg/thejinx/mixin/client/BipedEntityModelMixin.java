package com.thelgg.thejinx.mixin.client;

import com.thelgg.thejinx.client.render.TheJinxRenderState;
import net.minecraft.class_10034;
import net.minecraft.class_572;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_572.class)
public abstract class BipedEntityModelMixin {
    private static final float SINGLE_LEG_DROP = 3.0F;
    private static final float DOUBLE_LEG_DROP = 6.0F;

    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("TAIL"))
    private void theJinx$hideMissingParts(
            class_10034 state,
            CallbackInfo ci
    ) {
        if (!(state instanceof TheJinxRenderState jinxState)) {
            return;
        }

        BipedEntityModelAccessor accessor = (BipedEntityModelAccessor) this;
        accessor.theJinx$getHead().field_3665 = !jinxState.theJinx$isMissingHead();
        accessor.theJinx$getLeftArm().field_3665 = !jinxState.theJinx$isMissingLeftArm();
        accessor.theJinx$getRightArm().field_3665 = !jinxState.theJinx$isMissingRightArm();
        accessor.theJinx$getLeftLeg().field_3665 = !jinxState.theJinx$isMissingLeftLeg();
        accessor.theJinx$getRightLeg().field_3665 = !jinxState.theJinx$isMissingRightLeg();

        int missingLegs = 0;
        if (jinxState.theJinx$isMissingLeftLeg()) {
            missingLegs++;
        }
        if (jinxState.theJinx$isMissingRightLeg()) {
            missingLegs++;
        }

        float bodyDrop = switch (missingLegs) {
            case 1 -> SINGLE_LEG_DROP;
            case 2 -> DOUBLE_LEG_DROP;
            default -> 0.0F;
        };
        theJinx$applyUpperBodyDrop(accessor, bodyDrop);
    }

    private static void theJinx$applyUpperBodyDrop(BipedEntityModelAccessor accessor, float bodyDrop) {
        accessor.theJinx$getBody().field_3656 += bodyDrop;
        accessor.theJinx$getHead().field_3656 += bodyDrop;
        accessor.theJinx$getHat().field_3656 += bodyDrop;
        accessor.theJinx$getLeftArm().field_3656 += bodyDrop;
        accessor.theJinx$getRightArm().field_3656 += bodyDrop;
    }
}
