package com.thelgg.thejinx.mixin.client;

import com.thelgg.thejinx.client.render.TheJinxRenderState;
import com.thelgg.thejinx.data.JinxPlayerData;
import com.thelgg.thejinx.data.LimbPart;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void theJinx$copyMissingPartState(
            class_11890 player,
            class_10055 state,
            float tickDelta,
            CallbackInfo ci
    ) {
        if (!(player instanceof class_1657 playerEntity)) {
            return;
        }

        ((TheJinxRenderState) state).theJinx$setMissingParts(
                JinxPlayerData.get(playerEntity).hasMissingPart(LimbPart.HEAD),
                JinxPlayerData.get(playerEntity).hasMissingPart(LimbPart.LEFT_ARM),
                JinxPlayerData.get(playerEntity).hasMissingPart(LimbPart.RIGHT_ARM),
                JinxPlayerData.get(playerEntity).hasMissingPart(LimbPart.LEFT_LEG),
                JinxPlayerData.get(playerEntity).hasMissingPart(LimbPart.RIGHT_LEG)
        );
    }
}

