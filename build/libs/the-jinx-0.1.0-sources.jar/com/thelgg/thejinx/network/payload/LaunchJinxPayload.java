package com.thelgg.thejinx.network.payload;

import com.thelgg.thejinx.TheJinxMod;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record LaunchJinxPayload() implements class_8710 {
    public static final class_9154<LaunchJinxPayload> ID = new class_9154<>(class_2960.method_60655(TheJinxMod.MOD_ID, "launch_jinx"));
    public static final class_9139<class_9129, LaunchJinxPayload> CODEC = class_9139.method_56431(new LaunchJinxPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
