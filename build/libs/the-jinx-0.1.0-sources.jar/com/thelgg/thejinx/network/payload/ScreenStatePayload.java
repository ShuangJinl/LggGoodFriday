package com.thelgg.thejinx.network.payload;

import com.thelgg.thejinx.TheJinxMod;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ScreenStatePayload(boolean screenOpen) implements class_8710 {
    public static final class_8710.class_9154<ScreenStatePayload> ID = new class_8710.class_9154<>(
            class_2960.method_60655(TheJinxMod.MOD_ID, "screen_state")
    );

    public static final class_9139<class_9129, ScreenStatePayload> CODEC =
            class_9139.method_56434(class_9135.field_48547, ScreenStatePayload::screenOpen, ScreenStatePayload::new);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
